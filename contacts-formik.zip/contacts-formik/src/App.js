import ContactTable from './features/ContactTable';
import ContactForm from './features/ContactForm';


function App() {
  return (
    <div>
      <ContactForm />
      <ContactTable/>
    </div>
  );
}

export default App;
